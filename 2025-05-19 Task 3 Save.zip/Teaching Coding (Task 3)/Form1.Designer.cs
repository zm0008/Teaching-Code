﻿namespace Teaching_Coding__Task_3_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.homeToTutorial = new System.Windows.Forms.Button();
            this.pbBackground = new System.Windows.Forms.PictureBox();
            this.lblHome = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // homeToTutorial
            // 
            this.homeToTutorial.Font = new System.Drawing.Font("Microsoft YaHei", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeToTutorial.Location = new System.Drawing.Point(281, 184);
            this.homeToTutorial.Name = "homeToTutorial";
            this.homeToTutorial.Size = new System.Drawing.Size(243, 78);
            this.homeToTutorial.TabIndex = 0;
            this.homeToTutorial.Text = "Start";
            this.homeToTutorial.UseVisualStyleBackColor = true;
            this.homeToTutorial.Click += new System.EventHandler(this.homeToTutorial_Click);
            // 
            // pbBackground
            // 
            this.pbBackground.Image = ((System.Drawing.Image)(resources.GetObject("pbBackground.Image")));
            this.pbBackground.Location = new System.Drawing.Point(80, 11);
            this.pbBackground.Name = "pbBackground";
            this.pbBackground.Size = new System.Drawing.Size(640, 427);
            this.pbBackground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbBackground.TabIndex = 1;
            this.pbBackground.TabStop = false;
            // 
            // lblHome
            // 
            this.lblHome.BackColor = System.Drawing.SystemColors.Control;
            this.lblHome.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHome.Location = new System.Drawing.Point(109, 37);
            this.lblHome.Name = "lblHome";
            this.lblHome.Size = new System.Drawing.Size(576, 88);
            this.lblHome.TabIndex = 0;
            this.lblHome.Text = "Epic Coding Tutorialz";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 450);
            this.Controls.Add(this.lblHome);
            this.Controls.Add(this.homeToTutorial);
            this.Controls.Add(this.pbBackground);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbBackground)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button homeToTutorial;
        private System.Windows.Forms.PictureBox pbBackground;
        private System.Windows.Forms.Label lblHome;
    }
}

