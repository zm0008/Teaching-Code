﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linking_Forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Owner = this;
            form2.StartPosition = FormStartPosition.Manual;
            form2.Location = this.Location;
            form2.Show();
            this.Hide();
            form2.Label1Text = "Hello from form 1";
            form2.Label1Text = form2.getStr(); // setting label1text to form2's str

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string[] allLines = textBox1.Text.Split('\n');
            int count = 1;
            label1.Text = "";
            foreach (string text in allLines)
            {
                label1.Text = String.Format("{0}{1} {2}", label1.Text, count, text);
                count++;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
