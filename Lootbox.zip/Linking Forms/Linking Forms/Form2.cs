﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linking_Forms
{
    public partial class Form2 : Form
    {
        private string str = "";


        public Form2()
        {
            InitializeComponent();
            str = "helo";
        }

        public string getStr() {
            return this.str; 
        }
        public void setStr(string stringToSet)
        {
            this.str = stringToSet;
        }
        public string Label1Text
        {
            get { return label1.Text; }
            set { label1.Text = value; }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.StartPosition = FormStartPosition.Manual;
            form1.Location = this.Location;
            form1.Show();
            this.Close();
        }
    }
}
