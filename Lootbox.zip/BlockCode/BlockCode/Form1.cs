﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlockCode
{
    public partial class Form1 : Form
    {
        PictureBox[] pictures = new PictureBox[4];
        List<String> blocks = new List<string>();

        public Form1()
        {
            InitializeComponent();

            for (int i = 0; i < 4; i++)
            {
                pictures[i] = new PictureBox();
                pictures[i].SizeMode = PictureBoxSizeMode.StretchImage;
                pictures[i].AllowDrop = true;
                pictures[i].DragEnter += new DragEventHandler(pictures_DragEnter);
                pictures[i].DragDrop += new DragEventHandler(pictures_DragDrop);

                tblCodeArea.Controls.Add(pictures[i]);
            }
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void codeBlock_MouseDown(object sender, MouseEventArgs e)
        {
            PictureBox codeBlock = sender as PictureBox;

            DataObject dragImage = new DataObject();
            dragImage.SetData(DataFormats.Bitmap, true, codeBlock.Image);
            dragImage.SetData(DataFormats.Text, true, codeBlock.Tag);

            DoDragDrop(dragImage, DragDropEffects.Copy);
        }

        private void pictures_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.AllowedEffect;
        }

        private void pictures_DragDrop(object sender, DragEventArgs e)
        {
            PictureBox picture = sender as PictureBox;

            picture.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            picture.Tag = e.Data.GetData(TextDataFormat.Text.ToString());

            lblList.Text = "";
            blocks.Clear();

            for (int i = 0; i < 4; i++)
            {
                lblList.Text = String.Format("{0}{1} {2}\n", lblList.Text, i, pictures[i].Tag);

                blocks.Add(String.Format("{0}", pictures[i].Tag));

                if (blocks[i].Contains("For"))
                {
                    lblList.Text += "Initialise a For Loop here\n";
                }
                else if (blocks[i].Contains("When"))
                {
                    lblList.Text += "Initialise a Click Event here\n";
                }
            }
        }
    }
}
