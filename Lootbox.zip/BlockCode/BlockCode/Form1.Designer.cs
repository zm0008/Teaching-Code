﻿namespace BlockCode
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tblCodeArea = new System.Windows.Forms.TableLayoutPanel();
            this.pbWhenClicked = new System.Windows.Forms.PictureBox();
            this.lblList = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbWhenClicked)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tblCodeArea
            // 
            this.tblCodeArea.ColumnCount = 1;
            this.tblCodeArea.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCodeArea.Location = new System.Drawing.Point(12, 12);
            this.tblCodeArea.Name = "tblCodeArea";
            this.tblCodeArea.RowCount = 4;
            this.tblCodeArea.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblCodeArea.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 98F));
            this.tblCodeArea.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tblCodeArea.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tblCodeArea.Size = new System.Drawing.Size(237, 398);
            this.tblCodeArea.TabIndex = 0;
            // 
            // pbWhenClicked
            // 
            this.pbWhenClicked.Image = ((System.Drawing.Image)(resources.GetObject("pbWhenClicked.Image")));
            this.pbWhenClicked.Location = new System.Drawing.Point(313, 29);
            this.pbWhenClicked.Name = "pbWhenClicked";
            this.pbWhenClicked.Size = new System.Drawing.Size(142, 63);
            this.pbWhenClicked.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbWhenClicked.TabIndex = 1;
            this.pbWhenClicked.TabStop = false;
            this.pbWhenClicked.Tag = "When Clicked";
            this.pbWhenClicked.MouseDown += new System.Windows.Forms.MouseEventHandler(this.codeBlock_MouseDown);
            // 
            // lblList
            // 
            this.lblList.AutoSize = true;
            this.lblList.Location = new System.Drawing.Point(626, 57);
            this.lblList.Name = "lblList";
            this.lblList.Size = new System.Drawing.Size(35, 13);
            this.lblList.TabIndex = 2;
            this.lblList.Text = "label1";
            this.lblList.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(313, 116);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(142, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "For Loop";
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.codeBlock_MouseDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblList);
            this.Controls.Add(this.pbWhenClicked);
            this.Controls.Add(this.tblCodeArea);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbWhenClicked)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblCodeArea;
        private System.Windows.Forms.PictureBox pbWhenClicked;
        private System.Windows.Forms.Label lblList;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

