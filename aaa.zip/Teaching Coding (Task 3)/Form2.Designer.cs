﻿namespace Teaching_Coding__Task_3_
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTutorials = new System.Windows.Forms.Label();
            this.tutorialToHome = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.nextTo2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTutorials
            // 
            this.lblTutorials.Font = new System.Drawing.Font("Impact", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTutorials.Location = new System.Drawing.Point(179, 44);
            this.lblTutorials.Name = "lblTutorials";
            this.lblTutorials.Size = new System.Drawing.Size(436, 62);
            this.lblTutorials.TabIndex = 2;
            this.lblTutorials.Text = "Tutorial 1";
            this.lblTutorials.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tutorialToHome
            // 
            this.tutorialToHome.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tutorialToHome.Location = new System.Drawing.Point(25, 25);
            this.tutorialToHome.Name = "tutorialToHome";
            this.tutorialToHome.Size = new System.Drawing.Size(94, 31);
            this.tutorialToHome.TabIndex = 3;
            this.tutorialToHome.Text = "Home";
            this.tutorialToHome.UseVisualStyleBackColor = true;
            this.tutorialToHome.Click += new System.EventHandler(this.tutorialToHome_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(772, 122);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // nextTo2
            // 
            this.nextTo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextTo2.Location = new System.Drawing.Point(690, 383);
            this.nextTo2.Name = "nextTo2";
            this.nextTo2.Size = new System.Drawing.Size(94, 55);
            this.nextTo2.TabIndex = 5;
            this.nextTo2.Text = "Next";
            this.nextTo2.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 450);
            this.Controls.Add(this.nextTo2);
            this.Controls.Add(this.lblTutorials);
            this.Controls.Add(this.tutorialToHome);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTutorials;
        private System.Windows.Forms.Button tutorialToHome;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button nextTo2;
    }
}